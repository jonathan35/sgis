<?php
header("location:authentication/login.php");
?>