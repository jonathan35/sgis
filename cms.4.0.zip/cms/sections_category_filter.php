<script language="JavaScript">

function jumpMenu(target,selObj,restore){ 
  if (selObj.selectedIndex>0 && selObj.options[selObj.selectedIndex].value != ''){
    window.open(selObj.options[selObj.selectedIndex].value,target);}
  else if(selObj.options[selObj.selectedIndex].value == '')  {selObj.selectedIndex=0;}
  if (restore) selObj.selectedIndex=0;
}
</script>

<?
	
	
	
	if(strstr($_SERVER["REQUEST_URI"], 'news.php')){
		
				
	}else{
		

	}
	
	
	$main_category_filter = true;
	$sectionType_cond  = "and url_file = '' ";//"and section_type != 2 ";
	$current_sec_lvlpost_cond = '';
	
	/*if(!empty($_GET['m'])){
		$current_section_id =  base64_decode($_GET['m']);
		$_GET['main'] = $_GET['m'];
	}*/
	
	if($_GET['main']!=''){
		$current_section_id = $defenders->escapeInjection(base64_decode($_GET['main']));
	}
	
	if(!empty($current_section_id)){
		$current_section_qry = mysql_query("select * from sections_categories where maincat_id='".$current_section_id."%' ");
		$current_section=mysql_fetch_assoc($current_section_qry); 
		
		if(!empty($current_section['section_type'])){
			if($current_section['section_type'] == '2'){
				$main_category_filter = false;
				$sectionType_cond  = "and url_file != ''";
				$current_sec_lvlpost_cond = "and position like '".$current_section['position']."%'";
			}
		}	
	}
?>
<? 
if($main_category_filter == true){
	$qry = mysql_query("select * from sections_categories where status = 1 and length(position) = 1 $sectionType_cond order by maincat_name asc");
	$main = mysql_fetch_assoc($qry); 
?>
	<span class="content" style="padding-right:5px;">
		Filter:
		<select name="filter" style="width:150px;" onChange="javascript:jumpMenu('_self',this,0)">
			<option value="">Select section...</option>
			<option value="<? printf($currentPage); ?>?tab=<? echo $_GET['tab'];?>&all=1" <? if($_GET['all']==1){?> selected<? }?>> All section</option>
			<option value="<? printf($currentPage); ?>?tab=<? echo $_GET['tab'];?>&nocat=1" <? if($_GET['nocat']==1){?> selected<? }?>> No section</option>
		  <? do{ $maincat_Rs1=base64_encode($main['maincat_id']);?>
		  <option value="<? printf($currentPage); ?>?main=<? echo $maincat_Rs1;?>&tab=<? echo $_GET['tab'];?>" <? if($_GET['main']==$maincat_Rs1){?>selected<? }?>><? echo $main['maincat_name']; ?></option>
		  <? }while($main=mysql_fetch_assoc($qry)); ?>
		</select>
	</span>
		
		&nbsp;&nbsp;&nbsp;&nbsp;
<? }?>		
<? 

		$qry02=mysql_query("select * from sections_categories where status=1 and length(position)=2 $sectionType_cond $current_sec_lvlpost_cond order by maincat_name asc");
		$main02=mysql_fetch_assoc($qry02); 
?>

    <span class="content" style="padding-right:5px;">
        <select name="filter" style="width:150px;" onChange="javascript:jumpMenu('_self',this,0)">
            <option value="">Select category...</option>
            <!--<option value="<? printf($currentPage); ?>?tab=<? echo $_GET['tab'];?>&all=1&main=<?=$_GET['main']?>" <? if($_GET['all']==1){?> selected<? }?>> All category</option>-->
            <option value="<? printf($currentPage); ?>?tab=<? echo $_GET['tab'];?>&nocat=1&main=<?=$_GET['main']?>" <? if($_GET['nocat']==1){?> selected<? }?>> No category</option>
          <? do{ $maincat_Rs102=base64_encode($main02['maincat_id']);?>
          <option value="<? printf($currentPage); ?>?sub=<? echo $maincat_Rs102;?>&tab=<? echo $_GET['tab'];?>&main=<?=$_GET['main']?>" <? if($_GET['sub']==$maincat_Rs102){?>
          selected<? }?>><? echo $main02['maincat_name']; ?></option>
          <? }while($main02=mysql_fetch_assoc($qry02)); ?>
        </select>
    </span>                                  
